<?php

return [
    'failed' => 'Les credencials no són correctes.',
    'password' => 'La contrasenya no és correcta.',
    'throttle' => 'Massa intents. Torna-ho a provar d\'ací :seconds segons.',
];
