<?php

return [
    'reset' => 'La teua contrasenya ha sigut restablida!',
    'sent' => 'T\'hem enviat un enllaç per a restablir la teua contrasenya!',
    'throttled' => 'Espera abans de tornar-ho a intentar.',
    'token' => 'Aquest token de restabliment no és vàlid.',
    'user' => "No s'ha trobat cap usuari amb aquest correu electrònic.",
];
