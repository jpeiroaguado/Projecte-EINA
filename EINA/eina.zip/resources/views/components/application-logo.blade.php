<picture class="logo-container">
    <source srcset="{{ asset('images/logo-eina-icon.png') }}" media="(max-width: 640px)">
    <img src="{{ asset('images/logo-eina.png') }}" alt="Logo EINA" class="object-contain logoEINA">
</picture>
