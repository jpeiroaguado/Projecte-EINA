<picture class="logo-container">
    <source srcset="<?php echo e(asset('images/logo-eina-icon.png')); ?>" media="(max-width: 640px)">
    <img src="<?php echo e(asset('images/logo-eina.png')); ?>" alt="Logo EINA" class="object-contain logoEINA">
</picture>
<?php /**PATH /var/www/classe/Projecte_EINA/EINA/resources/views/components/application-logo.blade.php ENDPATH**/ ?>